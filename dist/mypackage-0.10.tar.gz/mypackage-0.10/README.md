# Demo Git Repository

This is the demo readme file for publishing python packages.

## For Building Locally
'pyhton setup.py sdist'

## Installing this package from GitHub
'pip install git+https://github/Muzix1/demo_package.git'

## Updating this package from GitHub
'pip install --upgrade git+https://github/Muzix1/demo_package.git'
